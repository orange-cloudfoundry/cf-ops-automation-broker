
package com.orange.oss.cloudfoundry.broker.opsautomation.ondemandbroker.terraform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cloudflare-route-ondemandroute5"
})
public class Module {

    @JsonProperty("cloudflare-route-ondemandroute5")
    public CloudflareRouteOndemandroute5 cloudflareRouteOndemandroute5;

    public Module withCloudflareRouteOndemandroute5(CloudflareRouteOndemandroute5 cloudflareRouteOndemandroute5) {
        this.cloudflareRouteOndemandroute5 = cloudflareRouteOndemandroute5;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cloudflareRouteOndemandroute5", cloudflareRouteOndemandroute5).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cloudflareRouteOndemandroute5).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Module) == false) {
            return false;
        }
        Module rhs = ((Module) other);
        return new EqualsBuilder().append(cloudflareRouteOndemandroute5, rhs.cloudflareRouteOndemandroute5).isEquals();
    }

}
