
package com.example;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cloudflare_internet_domain",
    "cloudflare_root_domain",
    "cloudflare_route_suffix",
    "org_guid",
    "route-prefix",
    "service_instance_guid",
    "source",
    "space_guid"
})
public class CloudflareRouteOndemandroute5 {

    @JsonProperty("cloudflare_internet_domain")
    private String cloudflareInternetDomain;
    @JsonProperty("cloudflare_root_domain")
    private String cloudflareRootDomain;
    @JsonProperty("cloudflare_route_suffix")
    private String cloudflareRouteSuffix;
    @JsonProperty("org_guid")
    private String orgGuid;
    @JsonProperty("route-prefix")
    private String routePrefix;
    @JsonProperty("service_instance_guid")
    private String serviceInstanceGuid;
    @JsonProperty("source")
    private String source;
    @JsonProperty("space_guid")
    private String spaceGuid;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cloudflare_internet_domain")
    public String getCloudflareInternetDomain() {
        return cloudflareInternetDomain;
    }

    @JsonProperty("cloudflare_internet_domain")
    public void setCloudflareInternetDomain(String cloudflareInternetDomain) {
        this.cloudflareInternetDomain = cloudflareInternetDomain;
    }

    public CloudflareRouteOndemandroute5 withCloudflareInternetDomain(String cloudflareInternetDomain) {
        this.cloudflareInternetDomain = cloudflareInternetDomain;
        return this;
    }

    @JsonProperty("cloudflare_root_domain")
    public String getCloudflareRootDomain() {
        return cloudflareRootDomain;
    }

    @JsonProperty("cloudflare_root_domain")
    public void setCloudflareRootDomain(String cloudflareRootDomain) {
        this.cloudflareRootDomain = cloudflareRootDomain;
    }

    public CloudflareRouteOndemandroute5 withCloudflareRootDomain(String cloudflareRootDomain) {
        this.cloudflareRootDomain = cloudflareRootDomain;
        return this;
    }

    @JsonProperty("cloudflare_route_suffix")
    public String getCloudflareRouteSuffix() {
        return cloudflareRouteSuffix;
    }

    @JsonProperty("cloudflare_route_suffix")
    public void setCloudflareRouteSuffix(String cloudflareRouteSuffix) {
        this.cloudflareRouteSuffix = cloudflareRouteSuffix;
    }

    public CloudflareRouteOndemandroute5 withCloudflareRouteSuffix(String cloudflareRouteSuffix) {
        this.cloudflareRouteSuffix = cloudflareRouteSuffix;
        return this;
    }

    @JsonProperty("org_guid")
    public String getOrgGuid() {
        return orgGuid;
    }

    @JsonProperty("org_guid")
    public void setOrgGuid(String orgGuid) {
        this.orgGuid = orgGuid;
    }

    public CloudflareRouteOndemandroute5 withOrgGuid(String orgGuid) {
        this.orgGuid = orgGuid;
        return this;
    }

    @JsonProperty("route-prefix")
    public String getRoutePrefix() {
        return routePrefix;
    }

    @JsonProperty("route-prefix")
    public void setRoutePrefix(String routePrefix) {
        this.routePrefix = routePrefix;
    }

    public CloudflareRouteOndemandroute5 withRoutePrefix(String routePrefix) {
        this.routePrefix = routePrefix;
        return this;
    }

    @JsonProperty("service_instance_guid")
    public String getServiceInstanceGuid() {
        return serviceInstanceGuid;
    }

    @JsonProperty("service_instance_guid")
    public void setServiceInstanceGuid(String serviceInstanceGuid) {
        this.serviceInstanceGuid = serviceInstanceGuid;
    }

    public CloudflareRouteOndemandroute5 withServiceInstanceGuid(String serviceInstanceGuid) {
        this.serviceInstanceGuid = serviceInstanceGuid;
        return this;
    }

    @JsonProperty("source")
    public String getSource() {
        return source;
    }

    @JsonProperty("source")
    public void setSource(String source) {
        this.source = source;
    }

    public CloudflareRouteOndemandroute5 withSource(String source) {
        this.source = source;
        return this;
    }

    @JsonProperty("space_guid")
    public String getSpaceGuid() {
        return spaceGuid;
    }

    @JsonProperty("space_guid")
    public void setSpaceGuid(String spaceGuid) {
        this.spaceGuid = spaceGuid;
    }

    public CloudflareRouteOndemandroute5 withSpaceGuid(String spaceGuid) {
        this.spaceGuid = spaceGuid;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public CloudflareRouteOndemandroute5 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cloudflareInternetDomain", cloudflareInternetDomain).append("cloudflareRootDomain", cloudflareRootDomain).append("cloudflareRouteSuffix", cloudflareRouteSuffix).append("orgGuid", orgGuid).append("routePrefix", routePrefix).append("serviceInstanceGuid", serviceInstanceGuid).append("source", source).append("spaceGuid", spaceGuid).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(orgGuid).append(cloudflareRootDomain).append(source).append(routePrefix).append(additionalProperties).append(spaceGuid).append(serviceInstanceGuid).append(cloudflareRouteSuffix).append(cloudflareInternetDomain).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CloudflareRouteOndemandroute5) == false) {
            return false;
        }
        CloudflareRouteOndemandroute5 rhs = ((CloudflareRouteOndemandroute5) other);
        return new EqualsBuilder().append(orgGuid, rhs.orgGuid).append(cloudflareRootDomain, rhs.cloudflareRootDomain).append(source, rhs.source).append(routePrefix, rhs.routePrefix).append(additionalProperties, rhs.additionalProperties).append(spaceGuid, rhs.spaceGuid).append(serviceInstanceGuid, rhs.serviceInstanceGuid).append(cloudflareRouteSuffix, rhs.cloudflareRouteSuffix).append(cloudflareInternetDomain, rhs.cloudflareInternetDomain).isEquals();
    }

}
