
package com.orange.oss.cloudfoundry.broker.opsautomation.ondemandbroker.terraform;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cloudflare_internet_domain",
    "cloudflare_root_domain",
    "cloudflare_route_suffix",
    "org_guid",
    "route-prefix",
    "service_instance_guid",
    "source",
    "space_guid"
})
public class CloudflareRouteOndemandroute5 {

    @JsonProperty("cloudflare_internet_domain")
    public String cloudflareInternetDomain;
    @JsonProperty("cloudflare_root_domain")
    public String cloudflareRootDomain;
    @JsonProperty("cloudflare_route_suffix")
    public String cloudflareRouteSuffix;
    @JsonProperty("org_guid")
    public String orgGuid;
    @JsonProperty("route-prefix")
    public String routePrefix;
    @JsonProperty("service_instance_guid")
    public String serviceInstanceGuid;
    @JsonProperty("source")
    public String source;
    @JsonProperty("space_guid")
    public String spaceGuid;

    public CloudflareRouteOndemandroute5 withCloudflareInternetDomain(String cloudflareInternetDomain) {
        this.cloudflareInternetDomain = cloudflareInternetDomain;
        return this;
    }

    public CloudflareRouteOndemandroute5 withCloudflareRootDomain(String cloudflareRootDomain) {
        this.cloudflareRootDomain = cloudflareRootDomain;
        return this;
    }

    public CloudflareRouteOndemandroute5 withCloudflareRouteSuffix(String cloudflareRouteSuffix) {
        this.cloudflareRouteSuffix = cloudflareRouteSuffix;
        return this;
    }

    public CloudflareRouteOndemandroute5 withOrgGuid(String orgGuid) {
        this.orgGuid = orgGuid;
        return this;
    }

    public CloudflareRouteOndemandroute5 withRoutePrefix(String routePrefix) {
        this.routePrefix = routePrefix;
        return this;
    }

    public CloudflareRouteOndemandroute5 withServiceInstanceGuid(String serviceInstanceGuid) {
        this.serviceInstanceGuid = serviceInstanceGuid;
        return this;
    }

    public CloudflareRouteOndemandroute5 withSource(String source) {
        this.source = source;
        return this;
    }

    public CloudflareRouteOndemandroute5 withSpaceGuid(String spaceGuid) {
        this.spaceGuid = spaceGuid;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cloudflareInternetDomain", cloudflareInternetDomain).append("cloudflareRootDomain", cloudflareRootDomain).append("cloudflareRouteSuffix", cloudflareRouteSuffix).append("orgGuid", orgGuid).append("routePrefix", routePrefix).append("serviceInstanceGuid", serviceInstanceGuid).append("source", source).append("spaceGuid", spaceGuid).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(orgGuid).append(cloudflareRootDomain).append(source).append(routePrefix).append(spaceGuid).append(serviceInstanceGuid).append(cloudflareRouteSuffix).append(cloudflareInternetDomain).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof CloudflareRouteOndemandroute5) == false) {
            return false;
        }
        CloudflareRouteOndemandroute5 rhs = ((CloudflareRouteOndemandroute5) other);
        return new EqualsBuilder().append(orgGuid, rhs.orgGuid).append(cloudflareRootDomain, rhs.cloudflareRootDomain).append(source, rhs.source).append(routePrefix, rhs.routePrefix).append(spaceGuid, rhs.spaceGuid).append(serviceInstanceGuid, rhs.serviceInstanceGuid).append(cloudflareRouteSuffix, rhs.cloudflareRouteSuffix).append(cloudflareInternetDomain, rhs.cloudflareInternetDomain).isEquals();
    }

}
